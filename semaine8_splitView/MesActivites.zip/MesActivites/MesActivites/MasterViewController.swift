//
//  MasterViewController.swift
//  
//
//  Created by Cao Sang DOAN on 23/11/15.
//
//

import UIKit

class MasterViewController: UIViewController {

}
